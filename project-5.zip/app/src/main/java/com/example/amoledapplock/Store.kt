package com.example.amoledapplock

import android.Manifest
import android.app.AppOpsManager
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.os.Build
import android.os.Process
import android.provider.Settings
import android.util.Base64
import androidx.core.content.ContextCompat
import java.security.MessageDigest
import java.security.SecureRandom
import java.util.concurrent.ConcurrentHashMap
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.PBEKeySpec

/** In-memory unlock state shared by the service and the lock screen (same process). */
object LockState {
    const val FOREVER = Long.MAX_VALUE
    val unlocked = ConcurrentHashMap<String, Long>()
    /** "package::chat name" -> unlocked-until timestamp */
    val chatUnlocked = ConcurrentHashMap<String, Long>()
    const val CHAT_STICKY_MS = 10 * 60 * 1000L
}

class Store(context: Context) {
    private val p: SharedPreferences =
        context.applicationContext.getSharedPreferences("app_lock", Context.MODE_PRIVATE)

    val hasPin: Boolean get() = p.getString("pin_hash", null) != null
    val pinLength: Int get() = p.getInt("pin_len", 0)

    var lockedApps: Set<String>
        get() = p.getStringSet("locked_apps", emptySet())?.toSet() ?: emptySet()
        set(v) { p.edit().putStringSet("locked_apps", v.toSet()).apply() }

    var chatLocks: Set<String>
        get() = p.getStringSet("chat_locks", emptySet())?.toSet() ?: emptySet()
        set(v) {
            p.edit().putStringSet("chat_locks", v.toSet()).apply()
            ChatLockService.instance?.refresh()
        }

    fun chatNames(pkg: String): List<String> =
        chatLocks.filter { it.startsWith("$pkg::") }.map { it.substringAfter("::") }

    val chatPackages: Set<String> get() = chatLocks.map { it.substringBefore("::") }.toSet()

    var enabled: Boolean
        get() = p.getBoolean("enabled", false)
        set(v) { p.edit().putBoolean("enabled", v).apply() }

    var biometric: Boolean
        get() = p.getBoolean("biometric", true)
        set(v) { p.edit().putBoolean("biometric", v).apply() }

    private fun hash(pin: String, salt: ByteArray): ByteArray =
        SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256")
            .generateSecret(PBEKeySpec(pin.toCharArray(), salt, 100_000, 256)).encoded

    fun setPin(pin: String) {
        val salt = ByteArray(16).also { SecureRandom().nextBytes(it) }
        p.edit()
            .putString("pin_salt", Base64.encodeToString(salt, Base64.NO_WRAP))
            .putString("pin_hash", Base64.encodeToString(hash(pin, salt), Base64.NO_WRAP))
            .putInt("pin_len", pin.length)
            .putInt("fails", 0)
            .putLong("lock_until", 0)
            .apply()
    }

    fun lockoutSeconds(): Long {
        val ms = p.getLong("lock_until", 0) - System.currentTimeMillis()
        return if (ms <= 0) 0 else ms / 1000 + 1
    }

    fun failMessage(): String {
        val s = lockoutSeconds()
        return if (s > 0) "Too many attempts. Try again in ${s}s" else "Wrong PIN"
    }

    /** Checks the PIN, with escalating lockouts after 5 wrong tries. */
    fun attempt(pin: String): Boolean {
        if (lockoutSeconds() > 0) return false
        val saltB64 = p.getString("pin_salt", null) ?: return false
        val stored = p.getString("pin_hash", null) ?: return false
        val ok = MessageDigest.isEqual(
            hash(pin, Base64.decode(saltB64, Base64.NO_WRAP)),
            Base64.decode(stored, Base64.NO_WRAP)
        )
        if (ok) {
            p.edit().putInt("fails", 0).apply()
        } else {
            val fails = p.getInt("fails", 0) + 1
            val e = p.edit().putInt("fails", fails)
            if (fails >= 5) {
                e.putLong("lock_until",
                    System.currentTimeMillis() + 30_000L * (1L shl minOf(fails - 5, 5)))
            }
            e.apply()
        }
        return ok
    }
}

object Perms {
    fun usage(c: Context): Boolean {
        val ops = c.getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
        @Suppress("DEPRECATION")
        val mode = ops.checkOpNoThrow(
            AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), c.packageName
        )
        return mode == AppOpsManager.MODE_ALLOWED
    }

    fun accessibility(c: Context): Boolean {
        val s = Settings.Secure.getString(
            c.contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
        ) ?: return false
        return s.split(':').any { it.startsWith("${c.packageName}/") && it.contains("ChatLockService") }
    }

    fun overlay(c: Context) = Settings.canDrawOverlays(c)

    fun notifications(c: Context) =
        Build.VERSION.SDK_INT < 33 ||
            ContextCompat.checkSelfPermission(c, Manifest.permission.POST_NOTIFICATIONS) ==
            PackageManager.PERMISSION_GRANTED

    fun ready(c: Context) = usage(c) && overlay(c)
}

fun startLockService(c: Context) {
    ContextCompat.startForegroundService(c, Intent(c, LockService::class.java))
}
