package com.example.amoledapplock

import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.graphics.drawable.toBitmap
import androidx.fragment.app.FragmentActivity

private val CHAT_PKGS = setOf(
    "com.whatsapp", "com.whatsapp.w4b", "com.instagram.android", "com.snapchat.android",
    "org.telegram.messenger", "com.facebook.orca", "com.discord",
    "com.google.android.apps.messaging", "com.samsung.android.messaging"
)

data class AppItem(val pkg: String, val label: String)
enum class Screen { Unlock, Main, SetPin }

class MainActivity : FragmentActivity() {

    private var tick by mutableIntStateOf(0)
    private var screen by mutableStateOf(Screen.Main)
    private lateinit var store: Store

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        store = Store(this)
        if (store.hasPin) screen = Screen.Unlock
        if (store.enabled && Perms.ready(this)) startLockService(this)
        val apps = loadApps()

        setContent {
            AppTheme {
                when (screen) {
                    Screen.Unlock -> {
                        val bio = store.biometric && canUseBiometric(this@MainActivity)
                        PinScreen(
                            title = "C-LOCK",
                            subtitle = "Enter PIN to continue",
                            autoLength = store.pinLength,
                            onSubmit = { pin ->
                                if (store.attempt(pin)) { screen = Screen.Main; null }
                                else store.failMessage()
                            },
                            onBiometric = if (bio) ({
                                promptBiometric("Unlock C-lock") { screen = Screen.Main }
                            }) else null
                        )
                    }
                    Screen.Main -> MainScreen(
                        this@MainActivity, store, apps, tick,
                        onChangePin = { screen = Screen.SetPin }
                    )
                    Screen.SetPin -> {
                        var first by remember { mutableStateOf<String?>(null) }
                        PinScreen(
                            title = if (first == null) "Create a PIN" else "Confirm PIN",
                            subtitle = "4–8 digits, then tap ✓",
                            autoLength = 0,
                            autoBiometric = false,
                            onCancel = { screen = Screen.Main },
                            onSubmit = { pin ->
                                val f = first
                                when {
                                    f == null -> { first = pin; null }
                                    pin == f -> { store.setPin(pin); screen = Screen.Main; null }
                                    else -> { first = null; "PINs didn't match. Start again." }
                                }
                            }
                        )
                    }
                }
            }
        }
    }

    override fun onResume() { super.onResume(); tick++ }

    override fun onStop() {
        super.onStop()
        if (!isChangingConfigurations && store.hasPin) screen = Screen.Unlock
    }

    private fun loadApps(): List<AppItem> {
        val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        return packageManager.queryIntentActivities(i, 0)
            .map { AppItem(it.activityInfo.packageName, it.loadLabel(packageManager).toString()) }
            .filter { it.pkg != packageName }
            .distinctBy { it.pkg }
            .sortedBy { it.label.lowercase() }
    }
}

@Composable
private fun MainScreen(
    act: FragmentActivity,
    store: Store,
    apps: List<AppItem>,
    tick: Int,
    onChangePin: () -> Unit
) {
    val usage = remember(tick) { Perms.usage(act) }
    val overlay = remember(tick) { Perms.overlay(act) }
    var notifOk by remember(tick) { mutableStateOf(Perms.notifications(act)) }
    val hasPin = remember(tick) { store.hasPin }
    var enabled by remember { mutableStateOf(store.enabled) }
    var bio by remember { mutableStateOf(store.biometric) }
    var locked by remember { mutableStateOf(store.lockedApps) }
    var query by remember { mutableStateOf("") }

    val notifLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { notifOk = it }

    val shown = remember(query, apps) { apps.filter { it.label.contains(query, ignoreCase = true) } }
    val pm = act.packageManager
    val a11y = remember(tick) { Perms.accessibility(act) }
    var disclosure by remember { mutableStateOf<String?>(null) }
    var chats by remember { mutableStateOf(store.chatLocks) }
    var chatApp by remember { mutableStateOf<String?>(null) }
    var chatName by remember { mutableStateOf("") }
    val chatApps = remember(apps) { apps.filter { it.pkg in CHAT_PKGS } }

    disclosure?.let { kind ->
        val isA11y = kind == "a11y"
        AlertDialog(
            onDismissRequest = { disclosure = null },
            containerColor = Panel,
            titleContentColor = Color.White,
            textContentColor = Color.White,
            title = { Text(if (isA11y) "Accessibility permission" else "Usage access permission") },
            text = {
                Text(
                    if (isA11y)
                        "C-lock uses Android's Accessibility Service for one purpose: to read the name shown at the top of a chat screen, only in the chat apps you choose, so it can ask for your PIN before that chat opens.\n\nIt only compares that text with the chat names you saved. Nothing it sees is stored, shared or sent anywhere, and C-lock has no internet access.\n\nNote: UPI and banking apps may refuse to open while this is on. Turn Chat lock off before using them."
                    else
                        "C-lock uses Usage access to detect which app you open, so it can show the lock screen over the apps you chose to protect.\n\nThis information stays on your phone. It is never stored or sent anywhere."
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    disclosure = null
                    act.startActivity(
                        Intent(
                            if (isA11y) Settings.ACTION_ACCESSIBILITY_SETTINGS
                            else Settings.ACTION_USAGE_ACCESS_SETTINGS
                        )
                    )
                }) { Text("Agree and continue", color = Red) }
            },
            dismissButton = {
                TextButton(onClick = { disclosure = null }) { Text("No thanks", color = Muted) }
            }
        )
    }

    LazyColumn(
        Modifier.fillMaxSize().systemBarsPadding().padding(horizontal = 18.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        item {
            Spacer(Modifier.height(12.dp))
            Text("C-LOCK", color = Red, fontSize = 28.sp, fontWeight = FontWeight.Bold)
            Text("Your phone. Your privacy.", color = Muted)
            Spacer(Modifier.height(8.dp))
        }

        item {
            Card(colors = CardDefaults.cardColors(containerColor = Panel)) {
                Column(Modifier.padding(14.dp)) {
                    Text("Setup", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                    SetupRow("PIN", hasPin, "Set PIN") { onChangePin() }
                    SetupRow("Usage access", usage, "Grant") { disclosure = "usage" }
                    SetupRow("Display over other apps", overlay, "Grant") {
                        act.startActivity(
                            Intent(
                                Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                                Uri.parse("package:${act.packageName}")
                            )
                        )
                    }
                    SetupRow("Notifications", notifOk, "Allow") {
                        if (Build.VERSION.SDK_INT >= 33) {
                            notifLauncher.launch(android.Manifest.permission.POST_NOTIFICATIONS)
                        }
                    }
                }
            }
        }

        item {
            Card(colors = CardDefaults.cardColors(containerColor = Panel)) {
                Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Chat lock", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                    Text(
                        "Lock one chat inside WhatsApp, Instagram and similar apps. Needs Protection enabled.",
                        color = Muted, fontSize = 13.sp
                    )
                    SetupRow("Accessibility service", a11y, "Enable") { disclosure = "a11y" }
                    Text(
                        "Heads up: while Chat lock is on, UPI and banking apps may refuse to open. That is a safety check in those apps. Turn Chat lock off before paying.",
                        color = Muted, fontSize = 12.sp
                    )
                    if (a11y) {
                        Button(
                            onClick = {
                                ChatLockService.instance?.pause()
                                Toast.makeText(act, "Chat lock turned off", Toast.LENGTH_SHORT).show()
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2A2A2A)),
                            modifier = Modifier.fillMaxWidth()
                        ) { Text("Turn off Chat lock (for UPI / banking)", color = Color.White) }
                    }
                    if (!a11y) {
                        Text(
                            "Switch greyed out? Open App info, tap the ⋮ menu, then Allow restricted settings.",
                            color = Muted, fontSize = 12.sp
                        )
                        TextButton(onClick = {
                            act.startActivity(
                                Intent(
                                    Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                                    Uri.parse("package:${act.packageName}")
                                )
                            )
                        }) { Text("Open App info", color = Red) }
                    }
                    if (chatApps.isEmpty()) {
                        Text("No supported chat apps found.", color = Muted)
                    } else {
                        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            chatApps.forEach { a ->
                                FilterChip(
                                    selected = chatApp == a.pkg,
                                    onClick = { chatApp = a.pkg },
                                    label = { Text(a.label) },
                                    colors = FilterChipDefaults.filterChipColors(
                                        selectedContainerColor = Red,
                                        selectedLabelColor = Color.White,
                                        labelColor = Color.White
                                    )
                                )
                            }
                        }
                    }
                    OutlinedTextField(
                        value = chatName,
                        onValueChange = { chatName = it },
                        label = { Text("Chat name, exactly as shown at top of the chat") },
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = Color.White, unfocusedTextColor = Color.White,
                            focusedBorderColor = Red, unfocusedBorderColor = Color.DarkGray,
                            focusedLabelColor = Red, unfocusedLabelColor = Muted, cursorColor = Red
                        ),
                        modifier = Modifier.fillMaxWidth()
                    )
                    Button(
                        enabled = chatApp != null && chatName.isNotBlank(),
                        onClick = {
                            chats = chats + "${chatApp}::${chatName.trim()}"
                            store.chatLocks = chats
                            chatName = ""
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = Red),
                        modifier = Modifier.fillMaxWidth()
                    ) { Text("Lock this chat", color = Color.White) }

                    chats.sorted().forEach { entry ->
                        val pkg = entry.substringBefore("::")
                        val name = entry.substringAfter("::")
                        val appLabel = apps.firstOrNull { it.pkg == pkg }?.label ?: pkg
                        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                            Text("$appLabel · $name", color = Color.White, modifier = Modifier.weight(1f))
                            TextButton(onClick = {
                                chats = chats - entry
                                store.chatLocks = chats
                            }) { Text("Remove", color = Red) }
                        }
                    }
                }
            }
        }

        item {
            Card(colors = CardDefaults.cardColors(containerColor = Panel)) {
                Column(Modifier.padding(14.dp)) {
                    ToggleRow("Protection enabled", enabled) { on ->
                        if (on && !(hasPin && usage && overlay)) {
                            Toast.makeText(
                                act, "Finish setup first (PIN, Usage access, Overlay)",
                                Toast.LENGTH_LONG
                            ).show()
                        } else {
                            enabled = on
                            store.enabled = on
                            if (on) startLockService(act)
                            else act.stopService(Intent(act, LockService::class.java))
                        }
                    }
                    ToggleRow("Fingerprint unlock", bio) { bio = it; store.biometric = it }
                    TextButton(onClick = onChangePin) {
                        Text(if (hasPin) "Change PIN" else "Set PIN", color = Red)
                    }
                }
            }
        }

        item {
            Spacer(Modifier.height(6.dp))
            Text(
                "Protected apps (${locked.size})",
                color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold
            )
            OutlinedTextField(
                value = query,
                onValueChange = { query = it },
                label = { Text("Search apps") },
                singleLine = true,
                colors = OutlinedTextFieldDefaults.colors(
                    focusedTextColor = Color.White, unfocusedTextColor = Color.White,
                    focusedBorderColor = Red, unfocusedBorderColor = Color.DarkGray,
                    focusedLabelColor = Red, unfocusedLabelColor = Muted, cursorColor = Red
                ),
                modifier = Modifier.fillMaxWidth()
            )
        }

        items(shown, key = { it.pkg }) { app ->
            val icon = remember(app.pkg) {
                runCatching { pm.getApplicationIcon(app.pkg).toBitmap(96, 96).asImageBitmap() }
                    .getOrNull()
            }
            Row(
                Modifier.fillMaxWidth()
                    .background(Panel, RoundedCornerShape(12.dp))
                    .padding(horizontal = 12.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                if (icon != null) {
                    Image(icon, contentDescription = null, modifier = Modifier.size(38.dp))
                    Spacer(Modifier.width(12.dp))
                }
                Text(app.label, color = Color.White, modifier = Modifier.weight(1f))
                Switch(
                    checked = app.pkg in locked,
                    onCheckedChange = { on ->
                        locked = if (on) locked + app.pkg else locked - app.pkg
                        store.lockedApps = locked
                    },
                    colors = switchColors()
                )
            }
        }

        item { Spacer(Modifier.height(24.dp)) }
    }
}

@Composable
private fun switchColors() = SwitchDefaults.colors(
    checkedThumbColor = Color.White, checkedTrackColor = Red,
    uncheckedThumbColor = Muted, uncheckedTrackColor = Color(0xFF222222),
    uncheckedBorderColor = Color(0xFF444444)
)

@Composable
private fun ToggleRow(label: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text(label, color = Color.White, modifier = Modifier.weight(1f))
        Switch(checked = checked, onCheckedChange = onChange, colors = switchColors())
    }
}

@Composable
private fun SetupRow(label: String, ok: Boolean, action: String, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text(
            if (ok) "✓" else "•",
            color = if (ok) Color(0xFF3DDC84) else Red,
            modifier = Modifier.width(24.dp)
        )
        Text(label, color = Color.White, modifier = Modifier.weight(1f))
        if (!ok) TextButton(onClick = onClick) { Text(action, color = Red) }
    }
}
