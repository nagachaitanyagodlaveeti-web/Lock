package com.example.amoledapplock

import android.app.*
import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ServiceInfo
import android.graphics.PixelFormat
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import androidx.core.app.NotificationCompat

class LockService : Service() {

    private val handler = Handler(Looper.getMainLooper())
    private lateinit var usm: UsageStatsManager
    private lateinit var store: Store
    private var lastTs = 0L
    private var foreground: String? = null
    private var lastLaunchPkg: String? = null
    private var lastLaunchAt = 0L
    private var anchor: View? = null

    private val screenOff = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) {
            LockState.unlocked.clear()
            LockState.chatUnlocked.clear()
            foreground = null
        }
    }

    private val poll = object : Runnable {
        override fun run() {
            try { check() } catch (_: Exception) {}
            handler.postDelayed(this, 250)
        }
    }

    override fun onCreate() {
        super.onCreate()
        usm = getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
        store = Store(this)
        lastTs = System.currentTimeMillis()
        registerReceiver(screenOff, IntentFilter(Intent.ACTION_SCREEN_OFF))
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val n = buildNotification()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(1, n)
        }
        if (!Perms.ready(this)) { stopSelf(); return START_NOT_STICKY }
        addAnchor()
        handler.removeCallbacks(poll)
        handler.post(poll)
        return START_STICKY
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        handler.removeCallbacks(poll)
        try { unregisterReceiver(screenOff) } catch (_: Exception) {}
        anchor?.let {
            try { (getSystemService(WINDOW_SERVICE) as WindowManager).removeView(it) } catch (_: Exception) {}
        }
        super.onDestroy()
    }

    private fun check() {
        val now = System.currentTimeMillis()
        val q = usm.queryEvents(maxOf(lastTs - 500, now - 30_000), now)
        val ev = UsageEvents.Event()
        while (q.hasNextEvent()) {
            q.getNextEvent(ev)
            if (ev.timeStamp <= lastTs) continue
            lastTs = ev.timeStamp
            when (ev.eventType) {
                FG_EVENT -> onForeground(ev.packageName, ev.timeStamp)
                BG_EVENT -> onBackground(ev.packageName, ev.timeStamp)
            }
        }
    }

    /** An app left the screen (home, recents, swiped away, screen off, switched app). */
    private fun onBackground(pkg: String, ts: Long) {
        if (pkg == packageName) return
        if (pkg == foreground) foreground = null
        LockState.unlocked.replace(pkg, LockState.FOREVER, ts + GRACE_MS)
        for ((k, v) in LockState.chatUnlocked) {
            if (k.startsWith("$pkg::") && v > ts + GRACE_MS) LockState.chatUnlocked[k] = ts + GRACE_MS
        }
    }

    private fun onForeground(pkg: String, ts: Long) {
        val prev = foreground
        if (pkg == prev) return
        foreground = pkg
        val now = ts

        // Leaving an unlocked app starts a short grace period.
        if (prev != null && prev != packageName && LockState.unlocked.containsKey(prev)) {
            LockState.unlocked[prev] = now + GRACE_MS
        }
        if (pkg == packageName) return
        if (!store.hasPin || pkg !in store.lockedApps) return

        val exp = LockState.unlocked[pkg]
        if (exp != null && exp >= now) {
            LockState.unlocked[pkg] = LockState.FOREVER
            return
        }
        LockState.unlocked.remove(pkg)
        launchLock(pkg, now)
    }

    private fun launchLock(pkg: String, now: Long) {
        if (pkg == lastLaunchPkg && now - lastLaunchAt < 1500) return
        lastLaunchPkg = pkg
        lastLaunchAt = now
        startActivity(
            Intent(this, LockActivity::class.java)
                .putExtra(LockActivity.EXTRA_PACKAGE, pkg)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_NO_ANIMATION)
        )
    }

    /** A 1px invisible overlay. It keeps this app allowed to start the lock screen from the background. */
    private fun addAnchor() {
        if (anchor != null || !Settings.canDrawOverlays(this)) return
        try {
            val lp = WindowManager.LayoutParams(
                1, 1,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT
            ).apply { gravity = Gravity.TOP or Gravity.START }
            val v = View(this)
            (getSystemService(WINDOW_SERVICE) as WindowManager).addView(v, lp)
            anchor = v
        } catch (_: Exception) {}
    }

    private fun buildNotification(): Notification {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL, "App lock", NotificationManager.IMPORTANCE_MIN)
        )
        val pi = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(this, CHANNEL)
            .setSmallIcon(android.R.drawable.ic_lock_lock)
            .setContentTitle("C-lock is active")
            .setContentIntent(pi)
            .setOngoing(true)
            .build()
    }

    companion object {
        private const val CHANNEL = "applock"
        private const val GRACE_MS = 2_000L
        @Suppress("DEPRECATION")
        private val FG_EVENT = UsageEvents.Event.MOVE_TO_FOREGROUND
        @Suppress("DEPRECATION")
        private val BG_EVENT = UsageEvents.Event.MOVE_TO_BACKGROUND
    }
}
