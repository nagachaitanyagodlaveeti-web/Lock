package com.example.amoledapplock

import android.accessibilityservice.AccessibilityService
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.PixelFormat
import android.graphics.Rect
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

/**
 * Looks for a locked chat's name in the header of the open chat screen
 * (and a message box near the bottom) in the apps you chose.
 */
class ChatLockService : AccessibilityService() {

    private lateinit var store: Store
    private val handler = Handler(Looper.getMainLooper())
    private var pending = false
    private var lastKey: String? = null
    private var lastAt = 0L
    private var anchor: View? = null

    private val screenOff = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) { LockState.chatUnlocked.clear() }
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        store = Store(this)
        instance = this
        registerReceiver(screenOff, IntentFilter(Intent.ACTION_SCREEN_OFF))
        addAnchor()
        refresh()
    }

    /** Only listen to apps that have a locked chat. */
    fun refresh() {
        val info = serviceInfo ?: return
        val pk = store.chatPackages
        info.packageNames = if (pk.isEmpty()) arrayOf("none.placeholder") else pk.toTypedArray()
        serviceInfo = info
    }

    override fun onAccessibilityEvent(e: AccessibilityEvent?) {
        val pkg = e?.packageName?.toString() ?: return
        if (pkg == packageName || pending) return
        pending = true
        handler.postDelayed({ pending = false; scan(pkg) }, 150)
    }

    override fun onInterrupt() {}

    private fun scan(pkg: String) {
        val names = store.chatNames(pkg).map(::norm).toSet()
        if (names.isEmpty() || !store.hasPin) return
        val root = rootInActiveWindow ?: return
        if (root.packageName?.toString() != pkg) return

        val now = System.currentTimeMillis()
        val match = findChat(root, names, resources.displayMetrics.heightPixels)

        if (match == null) {
            // Left the conversation: start a short countdown on any unlocked chat of this app.
            for ((k, v) in LockState.chatUnlocked) {
                if (k.startsWith("$pkg::") && v > now + LEAVE_GRACE_MS) {
                    LockState.chatUnlocked[k] = now + LEAVE_GRACE_MS
                }
            }
            return
        }

        val key = "$pkg::$match"
        val exp = LockState.chatUnlocked[key]
        if (exp != null && exp >= now) {
            LockState.chatUnlocked[key] = now + LockState.CHAT_STICKY_MS
            return
        }
        LockState.chatUnlocked.remove(key)
        if (key == lastKey && now - lastAt < 1500) return
        lastKey = key
        lastAt = now
        startActivity(
            Intent(this, LockActivity::class.java)
                .putExtra(LockActivity.EXTRA_PACKAGE, pkg)
                .putExtra(LockActivity.EXTRA_CHAT, match)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_NO_ANIMATION)
        )
    }

    private fun findChat(root: AccessibilityNodeInfo, names: Set<String>, screenH: Int): String? {
        val headerLimit = (screenH * 0.14).toInt()
        val composerTop = (screenH * 0.40).toInt()
        var header: String? = null
        var composer = false
        val r = Rect()
        val stack = ArrayDeque<AccessibilityNodeInfo>()
        stack.addLast(root)
        var visited = 0
        while (stack.isNotEmpty() && visited < 1500) {
            val n = stack.removeLast()
            visited++
            if (n.isVisibleToUser) {
                n.getBoundsInScreen(r)
                if (n.isEditable && r.top > composerTop) composer = true
                if (header == null && r.top < headerLimit) {
                    for (t in arrayOf(n.text, n.contentDescription)) {
                        val s = t?.toString()?.let(::norm)
                        if (s != null && s in names) header = s
                    }
                }
            }
            for (i in 0 until n.childCount) n.getChild(i)?.let { stack.addLast(it) }
        }
        return if (composer) header else null
    }

    private fun norm(s: String) = s.trim().lowercase().replace(Regex("\\s+"), " ")

    private fun addAnchor() {
        try {
            val lp = WindowManager.LayoutParams(
                1, 1,
                WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
                PixelFormat.TRANSLUCENT
            ).apply { gravity = Gravity.TOP or Gravity.START }
            val v = View(this)
            (getSystemService(WINDOW_SERVICE) as WindowManager).addView(v, lp)
            anchor = v
        } catch (_: Exception) {}
    }

    override fun onDestroy() {
        instance = null
        try { unregisterReceiver(screenOff) } catch (_: Exception) {}
        anchor?.let {
            try { (getSystemService(WINDOW_SERVICE) as WindowManager).removeView(it) } catch (_: Exception) {}
        }
        super.onDestroy()
    }

    companion object {
        @Volatile var instance: ChatLockService? = null
        private const val LEAVE_GRACE_MS = 4_000L
    }
}
