package com.example.amoledapplock

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

val Black = Color(0xFF000000)
val Panel = Color(0xFF141414)
val Red = Color(0xFFFF3030)
val Muted = Color(0xFF9A9A9A)

@Composable
fun AppTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Red, onPrimary = Color.White,
            background = Black, onBackground = Color.White,
            surface = Panel, onSurface = Color.White
        )
    ) {
        Surface(color = Black, modifier = Modifier.fillMaxSize()) { content() }
    }
}

@Composable
private fun Key(label: String, tint: Color = Color.White, onClick: () -> Unit) {
    Box(
        Modifier.size(78.dp).clip(CircleShape).background(Panel).clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) { Text(label, color = tint, fontSize = 26.sp) }
}

/**
 * onSubmit returns an error message, or null when accepted.
 * autoLength > 0 submits automatically once that many digits are typed.
 */
@Composable
fun PinScreen(
    title: String,
    subtitle: String,
    autoLength: Int,
    onSubmit: (String) -> String?,
    onBiometric: (() -> Unit)? = null,
    autoBiometric: Boolean = true,
    onCancel: (() -> Unit)? = null,
) {
    var pin by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }

    LaunchedEffect(Unit) { if (autoBiometric) onBiometric?.invoke() }

    fun submit(value: String) {
        if (value.length < 4) { error = "Enter at least 4 digits"; return }
        error = onSubmit(value)
        pin = ""
    }

    fun press(d: String) {
        if (pin.length >= 8) return
        val n = pin + d
        pin = n
        error = null
        if (autoLength > 0 && n.length == autoLength) submit(n)
    }

    Column(
        Modifier.fillMaxSize().systemBarsPadding().padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text(title, color = Red, fontSize = 24.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(6.dp))
        Text(subtitle, color = Muted)
        Spacer(Modifier.height(28.dp))

        Row(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
            repeat(maxOf(pin.length, if (autoLength > 0) autoLength else 4)) { i ->
                Box(
                    Modifier.size(16.dp).clip(CircleShape)
                        .background(if (i < pin.length) Red else Color(0xFF333333))
                )
            }
        }
        Spacer(Modifier.height(14.dp))
        Text(error ?: " ", color = Red, fontSize = 14.sp)
        Spacer(Modifier.height(14.dp))

        listOf(listOf("1", "2", "3"), listOf("4", "5", "6"), listOf("7", "8", "9")).forEach { row ->
            Row(horizontalArrangement = Arrangement.spacedBy(20.dp)) {
                row.forEach { d -> Key(d) { press(d) } }
            }
            Spacer(Modifier.height(16.dp))
        }
        Row(horizontalArrangement = Arrangement.spacedBy(20.dp)) {
            Key("⌫") { pin = pin.dropLast(1) }
            Key("0") { press("0") }
            Key("✓", Red) { submit(pin) }
        }

        Spacer(Modifier.height(18.dp))
        if (onBiometric != null) {
            TextButton(onClick = onBiometric) { Text("Use fingerprint", color = Red) }
        }
        if (onCancel != null) {
            TextButton(onClick = onCancel) { Text("Cancel", color = Muted) }
        }
    }
}
