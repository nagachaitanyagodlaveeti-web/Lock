package com.example.amoledapplock

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != Intent.ACTION_BOOT_COMPLETED) return
        if (Store(context).enabled && Perms.ready(context)) {
            try { startLockService(context) } catch (_: Exception) {}
        }
    }
}
