package com.example.amoledapplock

import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.os.Bundle
import android.view.WindowManager
import androidx.activity.OnBackPressedCallback
import androidx.activity.compose.setContent
import androidx.fragment.app.FragmentActivity

class LockActivity : FragmentActivity() {

    private lateinit var target: String

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.setBackgroundDrawable(ColorDrawable(Color.BLACK))
        window.addFlags(WindowManager.LayoutParams.FLAG_SECURE)

        target = intent.getStringExtra(EXTRA_PACKAGE) ?: run { finish(); return }
        val store = Store(this)
        val label = try {
            packageManager.getApplicationInfo(target, 0).loadLabel(packageManager).toString()
        } catch (e: Exception) { target }
        val bio = store.biometric && canUseBiometric(this)

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() = goHome()
        })

        setContent {
            AppTheme {
                PinScreen(
                    title = "$label is locked",
                    subtitle = "Enter PIN to continue",
                    autoLength = store.pinLength,
                    onSubmit = { pin ->
                        if (store.attempt(pin)) { unlock(); null } else store.failMessage()
                    },
                    onBiometric = if (bio) ({
                        promptBiometric("Unlock $label") { unlock() }
                    }) else null
                )
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        recreate()
    }

    private fun unlock() {
        LockState.unlocked[target] = LockState.FOREVER
        finish()
    }

    private fun goHome() {
        startActivity(
            Intent(Intent.ACTION_MAIN)
                .addCategory(Intent.CATEGORY_HOME)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        )
        finish()
    }

    companion object { const val EXTRA_PACKAGE = "pkg" }
}
