package com.example.amoledapplock

import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.graphics.drawable.toBitmap
import androidx.fragment.app.FragmentActivity

data class AppItem(val pkg: String, val label: String)
enum class Screen { Unlock, Main, SetPin }

class MainActivity : FragmentActivity() {

    private var tick by mutableIntStateOf(0)
    private var screen by mutableStateOf(Screen.Main)
    private lateinit var store: Store

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        store = Store(this)
        if (store.hasPin) screen = Screen.Unlock
        if (store.enabled && Perms.ready(this)) startLockService(this)
        val apps = loadApps()

        setContent {
            AppTheme {
                when (screen) {
                    Screen.Unlock -> {
                        val bio = store.biometric && canUseBiometric(this@MainActivity)
                        PinScreen(
                            title = "AMOLED LOCK",
                            subtitle = "Enter PIN to continue",
                            autoLength = store.pinLength,
                            onSubmit = { pin ->
                                if (store.attempt(pin)) { screen = Screen.Main; null }
                                else store.failMessage()
                            },
                            onBiometric = if (bio) ({
                                promptBiometric("Unlock AMOLED Lock") { screen = Screen.Main }
                            }) else null
                        )
                    }
                    Screen.Main -> MainScreen(
                        this@MainActivity, store, apps, tick,
                        onChangePin = { screen = Screen.SetPin }
                    )
                    Screen.SetPin -> {
                        var first by remember { mutableStateOf<String?>(null) }
                        PinScreen(
                            title = if (first == null) "Create a PIN" else "Confirm PIN",
                            subtitle = "4–8 digits, then tap ✓",
                            autoLength = 0,
                            autoBiometric = false,
                            onCancel = { screen = Screen.Main },
                            onSubmit = { pin ->
                                val f = first
                                when {
                                    f == null -> { first = pin; null }
                                    pin == f -> { store.setPin(pin); screen = Screen.Main; null }
                                    else -> { first = null; "PINs didn't match. Start again." }
                                }
                            }
                        )
                    }
                }
            }
        }
    }

    override fun onResume() { super.onResume(); tick++ }

    override fun onStop() {
        super.onStop()
        if (!isChangingConfigurations && store.hasPin) screen = Screen.Unlock
    }

    private fun loadApps(): List<AppItem> {
        val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        return packageManager.queryIntentActivities(i, 0)
            .map { AppItem(it.activityInfo.packageName, it.loadLabel(packageManager).toString()) }
            .filter { it.pkg != packageName }
            .distinctBy { it.pkg }
            .sortedBy { it.label.lowercase() }
    }
}

@Composable
private fun MainScreen(
    act: FragmentActivity,
    store: Store,
    apps: List<AppItem>,
    tick: Int,
    onChangePin: () -> Unit
) {
    val usage = remember(tick) { Perms.usage(act) }
    val overlay = remember(tick) { Perms.overlay(act) }
    var notifOk by remember(tick) { mutableStateOf(Perms.notifications(act)) }
    val hasPin = remember(tick) { store.hasPin }
    var enabled by remember { mutableStateOf(store.enabled) }
    var bio by remember { mutableStateOf(store.biometric) }
    var locked by remember { mutableStateOf(store.lockedApps) }
    var query by remember { mutableStateOf("") }

    val notifLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { notifOk = it }

    val shown = remember(query, apps) { apps.filter { it.label.contains(query, ignoreCase = true) } }
    val pm = act.packageManager

    LazyColumn(
        Modifier.fillMaxSize().systemBarsPadding().padding(horizontal = 18.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        item {
            Spacer(Modifier.height(12.dp))
            Text("AMOLED LOCK", color = Red, fontSize = 28.sp, fontWeight = FontWeight.Bold)
            Text("Your phone. Your privacy.", color = Muted)
            Spacer(Modifier.height(8.dp))
        }

        item {
            Card(colors = CardDefaults.cardColors(containerColor = Panel)) {
                Column(Modifier.padding(14.dp)) {
                    Text("Setup", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                    SetupRow("PIN", hasPin, "Set PIN") { onChangePin() }
                    SetupRow("Usage access", usage, "Grant") {
                        act.startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS))
                    }
                    SetupRow("Display over other apps", overlay, "Grant") {
                        act.startActivity(
                            Intent(
                                Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                                Uri.parse("package:${act.packageName}")
                            )
                        )
                    }
                    SetupRow("Notifications", notifOk, "Allow") {
                        if (Build.VERSION.SDK_INT >= 33) {
                            notifLauncher.launch(android.Manifest.permission.POST_NOTIFICATIONS)
                        }
                    }
                }
            }
        }

        item {
            Card(colors = CardDefaults.cardColors(containerColor = Panel)) {
                Column(Modifier.padding(14.dp)) {
                    ToggleRow("Protection enabled", enabled) { on ->
                        if (on && !(hasPin && usage && overlay)) {
                            Toast.makeText(
                                act, "Finish setup first (PIN, Usage access, Overlay)",
                                Toast.LENGTH_LONG
                            ).show()
                        } else {
                            enabled = on
                            store.enabled = on
                            if (on) startLockService(act)
                            else act.stopService(Intent(act, LockService::class.java))
                        }
                    }
                    ToggleRow("Fingerprint unlock", bio) { bio = it; store.biometric = it }
                    TextButton(onClick = onChangePin) {
                        Text(if (hasPin) "Change PIN" else "Set PIN", color = Red)
                    }
                }
            }
        }

        item {
            Spacer(Modifier.height(6.dp))
            Text(
                "Protected apps (${locked.size})",
                color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold
            )
            OutlinedTextField(
                value = query,
                onValueChange = { query = it },
                label = { Text("Search apps") },
                singleLine = true,
                colors = OutlinedTextFieldDefaults.colors(
                    focusedTextColor = Color.White, unfocusedTextColor = Color.White,
                    focusedBorderColor = Red, unfocusedBorderColor = Color.DarkGray,
                    focusedLabelColor = Red, unfocusedLabelColor = Muted, cursorColor = Red
                ),
                modifier = Modifier.fillMaxWidth()
            )
        }

        items(shown, key = { it.pkg }) { app ->
            val icon = remember(app.pkg) {
                runCatching { pm.getApplicationIcon(app.pkg).toBitmap(96, 96).asImageBitmap() }
                    .getOrNull()
            }
            Row(
                Modifier.fillMaxWidth()
                    .background(Panel, RoundedCornerShape(12.dp))
                    .padding(horizontal = 12.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                if (icon != null) {
                    Image(icon, contentDescription = null, modifier = Modifier.size(38.dp))
                    Spacer(Modifier.width(12.dp))
                }
                Text(app.label, color = Color.White, modifier = Modifier.weight(1f))
                Switch(
                    checked = app.pkg in locked,
                    onCheckedChange = { on ->
                        locked = if (on) locked + app.pkg else locked - app.pkg
                        store.lockedApps = locked
                    },
                    colors = switchColors()
                )
            }
        }

        item { Spacer(Modifier.height(24.dp)) }
    }
}

@Composable
private fun switchColors() = SwitchDefaults.colors(
    checkedThumbColor = Color.White, checkedTrackColor = Red,
    uncheckedThumbColor = Muted, uncheckedTrackColor = Color(0xFF222222),
    uncheckedBorderColor = Color(0xFF444444)
)

@Composable
private fun ToggleRow(label: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text(label, color = Color.White, modifier = Modifier.weight(1f))
        Switch(checked = checked, onCheckedChange = onChange, colors = switchColors())
    }
}

@Composable
private fun SetupRow(label: String, ok: Boolean, action: String, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text(
            if (ok) "✓" else "•",
            color = if (ok) Color(0xFF3DDC84) else Red,
            modifier = Modifier.width(24.dp)
        )
        Text(label, color = Color.White, modifier = Modifier.weight(1f))
        if (!ok) TextButton(onClick = onClick) { Text(action, color = Red) }
    }
}
